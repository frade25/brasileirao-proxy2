# Proxy Sofascore para Calendário Brasileirão

Este projeto é um pequeno servidor (via função serverless) que serve como proxy para a API da Sofascore, contornando o problema de CORS.

## Como usar

1. Crie um novo repositório no GitHub e envie esta pasta inteira (incluindo a pasta `/api/`).
2. Vá até https://vercel.com/import e selecione esse repositório para importar.
3. O Vercel vai detectar automaticamente a função serverless.
4. Após o deploy, você verá uma URL como:

   `https://seu-projeto.vercel.app/api/proxy`

5. Use essa URL no seu `index.html` para fazer o `fetch` sem erro de CORS.

## Exemplo de uso no HTML:

```js
const response = await fetch('https://seu-projeto.vercel.app/api/proxy');
```

Substitua `seu-projeto` pelo endereço gerado no deploy.
